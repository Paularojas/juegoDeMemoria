//: Playground - noun: a place where people can play

import Cocoa


var numeros = 1...100

for miNumero in numeros{
    
    if miNumero % 5 == 0{
        
        print("\(miNumero)" + "\tBingo!!!")
        
    }
        
    else if miNumero > 29 && miNumero < 41{
        
        print("\(miNumero)" + "\tViva Swift!!!")
        
    }
        
    else if miNumero % 2 == 0{
        
        print("\(miNumero)" + "\tpar!!!")
        
    }
        
    else{
        
        print("\(miNumero)" + "\timpar!!!")
        
    }
    
}
